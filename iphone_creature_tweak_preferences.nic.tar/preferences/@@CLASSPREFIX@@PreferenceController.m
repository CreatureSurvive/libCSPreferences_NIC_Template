#include "@@CLASSPREFIX@@PreferenceController.h"

@implementation @@CLASSPREFIX@@PreferenceController

@end
