#import <CSPreferences/libCSPreferences.h>

@interface @@CLASSPREFIX@@PreferenceController : CSPListController

@end