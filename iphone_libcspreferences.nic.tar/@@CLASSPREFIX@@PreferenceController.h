#import <libCSPreferences.h>

@interface @@CLASSPREFIX@@PreferenceController : CSPListController

@end